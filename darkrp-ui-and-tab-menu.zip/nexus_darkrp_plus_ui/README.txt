NEXUS DarkRP Plus UI

Папка отдельная от lockpick/tab аддона:
- addons/nexus_darkrp_plus_ui/

Файлы:
- lua/autorun/sh_nexus_plus_config.lua
- lua/autorun/server/sv_nexus_plus.lua
- lua/autorun/client/cl_nexus_plus_f4.lua
- lua/autorun/client/cl_nexus_plus_cmenu.lua
- lua/autorun/client/cl_nexus_plus_door.lua
- lua/autorun/client/cl_nexus_plus_hud.lua
- lua/autorun/client/cl_nexus_plus_esc.lua
- lua/autorun/client/cl_nexus_plus_chat.lua

Функции:
- F4 меню (карточки с моделями, выбор профессии через отдельное окно с описанием)
- F4 закрывается повторным нажатием F4
- CMenu (кастом по C, узкое окно справа)
- Меню двери (покупка, продажа, название)
- Меню двери для superadmin показывает admin функции
- Superadmin может установить группу двери (door group)
- Кастомный HUD (здоровье, броня, сытость, зарплата, розыск, арест, ком. час, аммо, agenda)
- HUD использует 3D2D инфо при наведении (над игроком и на двери)
- Кастомный ESC Menu
- Кастомный ChatBox
- Премиум ChatBox: фильтры каналов, fade-история, подсказки команд, история ввода (UP/DOWN)

Важно по двери:
- Команды покупки/продажи/названия настраиваются в конфиге Door:
  - buyDoorCommand
  - sellDoorCommand
  - titleCommand
  - doorGroupChatCommand

Команды:
- nexus_plus_f4
- nexus_plus_door_menu

Конфиг:
- Все настройки, размеры, анимации и кнопки в sh_nexus_plus_config.lua