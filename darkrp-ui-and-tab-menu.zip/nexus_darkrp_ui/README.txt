NEXUS DarkRP UI addon

Что внутри:
- lua/autorun/sh_nexus_ui_config.lua
- lua/autorun/client/cl_nexus_lockpick.lua
- lua/autorun/client/cl_nexus_tab.lua
- lua/autorun/server/sv_nexus_lockpick.lua
- lua/autorun/server/sv_nexus_tab.lua

Установка:
1. Скопируйте папку nexus_darkrp_ui в garrysmod/addons/
2. Перезапустите сервер.

Как использовать lockpick:
- Встаньте рядом с дверью и введите в консоль: nexus_lockpick
- Или на сервере: nexus_lockpick_start
- Также доступны команды в чат: /lockpick и !lockpick

Как использовать TAB меню:
- Просто удерживайте TAB, меню заменит стандартный scoreboard.
- Нажмите по строке игрока, чтобы открыть действия:
  - Скопировать SteamID
  - Открыть Steam профиль
  - Телепорт к игроку через "sam teleport"

Конфиг:
- Все настройки в lua/autorun/sh_nexus_ui_config.lua
- Lockpick и Tab полностью разделены по логике и серверным файлам.
- TAB кнопки действий настраиваются в NEXUS_UI_CONFIG.Tab.actions (id/label/icon/enabled).

Права на teleport:
- Доступно только admin/superadmin.
- Если SAM не установлен, включается fallback teleport для теста.

Для интеграции с вашим SWEP/системой:
- Вызывайте NEXUS_LOCKPICK.StartForPlayer(ply, doorEntity)

Диагностика:
- Проверьте, что папка лежит строго в garrysmod/addons/nexus_darkrp_ui/
- После копирования обязательно полный рестарт сервера.
- Для быстрой проверки lockpick: команда nexus_lockpick в клиентской консоли рядом с дверью.