if SERVER then return end

surface.CreateFont("NexusLockpickTitle", {
    font = "Roboto",
    size = 42,
    weight = 700,
    antialias = true
})

surface.CreateFont("NexusLockpickHeader", {
    font = "Roboto",
    size = 40,
    weight = 500,
    antialias = true
})

surface.CreateFont("NexusLockpickText", {
    font = "Roboto",
    size = 18,
    weight = 500,
    antialias = true
})

local PANEL = {}

local function cfgValue(key, fallback)
    local cfg = NEXUS_UI_CONFIG and NEXUS_UI_CONFIG.Lockpick
    if not cfg then return fallback end

    local value = cfg[key]
    if value == nil then return fallback end
    return value
end

function PANEL:Init()
    self:SetSize(cfgValue("panelWidth", 440), cfgValue("panelHeight", 220))
    self:Center()
    self:SetTitle("")
    self:SetDraggable(false)
    self:ShowCloseButton(false)
    self:SetDeleteOnClose(true)

    self.required = 6
    self.hits = 0
    self.endsAt = CurTime() + 42
    self.goalStart = 0.35
    self.goalSize = cfgValue("zoneSize", 0.2)
    self.marker = 0
    self.direction = 1
    self.statusText = "Попадите в зеленую зону несколько раз"
    self.statusColor = Color(210, 210, 220)
    self.lastInput = 0
    self.appear = 0

    self.actionButton = vgui.Create("DButton", self)
    self.actionButton:SetText("ВЗЛОМАТЬ")
    self.actionButton:SetFont("NexusLockpickText")
    self.actionButton:SetTextColor(color_white)
    self.actionButton.hover = 0

    self.actionButton.Paint = function(btn, w, h)
        btn.hover = Lerp(FrameTime() * 12, btn.hover, btn:IsHovered() and 1 or 0)

        local r = Lerp(btn.hover, 60, 74)
        local g = Lerp(btn.hover, 103, 123)
        local b = Lerp(btn.hover, 177, 214)
        draw.RoundedBox(8, 0, 0, w, h, Color(r, g, b, 255))

        if btn:IsDown() then
            draw.RoundedBox(8, 1, 1, w - 2, h - 2, Color(0, 0, 0, 28))
        end
    end

    self.actionButton.DoClick = function()
        self:TryHit()
    end
end

function PANEL:Setup(required, seconds)
    self.required = required or 6
    self.hits = 0
    self.endsAt = CurTime() + (seconds or 42)
end

function PANEL:Think()
    self.appear = Lerp(FrameTime() * 10, self.appear, 1)

    local dt = FrameTime() * cfgValue("markerSpeed", 0.78)
    self.marker = self.marker + (dt * self.direction)

    if self.marker >= 1 then
        self.marker = 1
        self.direction = -1
    elseif self.marker <= 0 then
        self.marker = 0
        self.direction = 1
    end

    if self.endsAt <= CurTime() then
        net.Start("nexus_lockpick_input")
        net.WriteBool(false)
        net.SendToServer()
        self:Close()
        return
    end

    self.actionButton:SetPos(110, 156)
    self.actionButton:SetSize(self:GetWide() - 220, 36)
end

function PANEL:Paint(w, h)
    local alpha = math.floor(Lerp(self.appear, 0, 236))
    local offset = Lerp(self.appear, 10, 0)

    draw.RoundedBox(10, 0, offset, w, h - offset, Color(33, 15, 19, alpha))
    draw.SimpleText("NEXUS", "NexusLockpickTitle", w * 0.5, 14 + offset, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER)
    draw.SimpleText("Взлом замка", "NexusLockpickHeader", w * 0.5, 52 + offset, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER)
    draw.SimpleText(self.statusText, "NexusLockpickText", w * 0.5, 98 + offset, self.statusColor, TEXT_ALIGN_CENTER)

    local smallX, smallY, smallW, smallH = 40, 118, w - 80, 14
    draw.RoundedBox(6, smallX, smallY + offset, smallW, smallH, Color(43, 48, 66, alpha))
    draw.SimpleText(self.hits .. " / " .. self.required, "NexusLockpickText", w * 0.5, smallY + (smallH * 0.5) + offset, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    local barX, barY, barW, barH = 40, 140, w - 80, 28
    draw.RoundedBox(8, barX, barY + offset, barW, barH, Color(43, 48, 66, alpha))
    draw.RoundedBox(8, barX + (barW * self.goalStart), barY + offset, barW * self.goalSize, barH, Color(58, 182, 88, alpha))
    draw.RoundedBox(0, barX + (barW * self.marker) - 2, barY + offset - 2, 4, barH + 4, Color(255, 255, 255, alpha))

    local left = math.max(0, math.ceil(self.endsAt - CurTime()))
    draw.SimpleText("Время раунда: 0:" .. string.format("%02d", left), "NexusLockpickText", w * 0.5, 204 + offset, Color(210, 210, 220, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

function PANEL:TryHit()
    if self.lastInput > CurTime() then return end
    self.lastInput = CurTime() + 0.2

    local success = self.marker >= self.goalStart and self.marker <= (self.goalStart + self.goalSize)

    net.Start("nexus_lockpick_input")
    net.WriteBool(success)
    net.SendToServer()

    if success then
        self.statusText = "Точное попадание"
        self.statusColor = Color(110, 232, 149)
        self.goalStart = math.Rand(cfgValue("zoneMin", 0.08), cfgValue("zoneMax", 0.72))
    else
        self.statusText = "Промах"
        self.statusColor = Color(255, 156, 156)
    end
end

function PANEL:OnKeyCodePressed(keyCode)
    if keyCode == KEY_SPACE or keyCode == KEY_ENTER then
        self:TryHit()
    end
end

vgui.Register("NexusLockpickFrame", PANEL, "DFrame")

local lockpickFrame

net.Receive("nexus_lockpick_open", function()
    local required = net.ReadUInt(8)
    local seconds = net.ReadUInt(8)

    if IsValid(lockpickFrame) then
        lockpickFrame:Remove()
    end

    lockpickFrame = vgui.Create("NexusLockpickFrame")
    lockpickFrame:Setup(required, seconds)
    lockpickFrame:MakePopup()
end)

net.Receive("nexus_lockpick_update", function()
    local hits = net.ReadUInt(8)
    local required = net.ReadUInt(8)
    local timeLeft = net.ReadUInt(8)
    local success = net.ReadBool()

    if not IsValid(lockpickFrame) then return end

    lockpickFrame.hits = hits
    lockpickFrame.required = required
    lockpickFrame.endsAt = CurTime() + timeLeft
    lockpickFrame.statusText = success and "Точное попадание" or "Штраф по времени"
    lockpickFrame.statusColor = success and Color(110, 232, 149) or Color(255, 166, 130)
end)

net.Receive("nexus_lockpick_close", function()
    local success = net.ReadBool()
    local message = net.ReadString()

    if IsValid(lockpickFrame) then
        lockpickFrame:Remove()
    end

    chat.AddText(success and Color(90, 220, 120) or Color(220, 80, 80), "[NEXUS] ", color_white, message)
end)

concommand.Add("nexus_lockpick", function()
    net.Start("nexus_lockpick_request")
    net.SendToServer()
end)