import { useEffect, useMemo, useState } from "react";

const REQUIRED_HITS = 6;
const ROUND_SECONDS = 42;

const players = [
  { name: "nexus_admin", job: "Мэр", ping: 21, money: "$145 000" },
  { name: "volk_ivan", job: "Начальник полиции", ping: 36, money: "$61 500" },
  { name: "ghost_lime", job: "Вор", ping: 47, money: "$12 000" },
  { name: "sm0ke", job: "Гражданин", ping: 18, money: "$4 650" },
  { name: "raven", job: "Медик", ping: 29, money: "$18 900" },
  { name: "striker", job: "Оружейник", ping: 55, money: "$41 300" },
];

const lockpickLua = `-- lua/autorun/client/cl_nexus_lockpick.lua
if SERVER then return end

local PANEL = {}

function PANEL:Init()
    self:SetSize(440, 200)
    self:Center()
    self:SetTitle("")
    self:ShowCloseButton(false)
    self:SetDraggable(false)
    self.progress = 0
    self.goalStart = 0.35
    self.goalSize = 0.22
    self.marker = 0
    self.direction = 1
    self.hits = 0
    self.required = 6
end

function PANEL:Think()
    self.marker = self.marker + (FrameTime() * 0.65 * self.direction)
    if self.marker >= 1 then
        self.marker = 1
        self.direction = -1
    elseif self.marker <= 0 then
        self.marker = 0
        self.direction = 1
    end
end

function PANEL:Paint(w, h)
    draw.RoundedBox(10, 0, 0, w, h, Color(32, 16, 18, 235))
    draw.SimpleText("Взлом замка", "Trebuchet24", w / 2, 22, color_white, TEXT_ALIGN_CENTER)
    draw.SimpleText(self.hits .. " / " .. self.required, "Trebuchet18", w / 2, 48, Color(210, 210, 210), TEXT_ALIGN_CENTER)

    local barX, barY, barW, barH = 28, 78, w - 56, 26
    draw.RoundedBox(6, barX, barY, barW, barH, Color(38, 41, 57))
    draw.RoundedBox(6, barX + (barW * self.goalStart), barY, barW * self.goalSize, barH, Color(59, 182, 92))
    draw.RoundedBox(0, barX + (barW * self.marker), barY - 2, 4, barH + 4, color_white)

    draw.RoundedBox(8, 80, 136, w - 160, 36, Color(56, 99, 176))
    draw.SimpleText("Взломать", "Trebuchet18", w / 2, 154, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

function PANEL:OnMousePressed(mc)
    if mc ~= MOUSE_LEFT then return end
    local success = self.marker >= self.goalStart and self.marker <= (self.goalStart + self.goalSize)
    if success then
        self.hits = self.hits + 1
        if self.hits >= self.required then
            net.Start("nexus_lockpick_result")
            net.WriteBool(true)
            net.SendToServer()
            self:Remove()
        end
    else
        net.Start("nexus_lockpick_result")
        net.WriteBool(false)
        net.SendToServer()
    end
end

vgui.Register("NexusLockpickPanel", PANEL, "DFrame")

net.Receive("nexus_open_lockpick", function()
    if IsValid(g_NexusLockpick) then g_NexusLockpick:Remove() end
    g_NexusLockpick = vgui.Create("NexusLockpickPanel")
    g_NexusLockpick:MakePopup()
end)
`;

const tabLua = `-- lua/autorun/client/cl_nexus_tab.lua
if SERVER then return end

local frame

hook.Add("ScoreboardShow", "Nexus_OpenScoreboard", function()
    if IsValid(frame) then frame:Remove() end

    frame = vgui.Create("DFrame")
    frame:SetSize(ScrW() * 0.72, ScrH() * 0.72)
    frame:Center()
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)
    frame:MakePopup()

    frame.Paint = function(_, w, h)
        draw.RoundedBox(14, 0, 0, w, h, Color(18, 18, 24, 235))
        draw.SimpleText("NEXUS DARKRP", "Trebuchet24", 26, 24, Color(255, 255, 255))
        draw.SimpleText("Онлайн: " .. player.GetCount(), "Trebuchet18", 26, 52, Color(180, 180, 190))
    end

    local list = vgui.Create("DScrollPanel", frame)
    list:Dock(FILL)
    list:DockMargin(16, 86, 16, 16)

    for _, ply in ipairs(player.GetAll()) do
        local row = list:Add("DButton")
        row:Dock(TOP)
        row:DockMargin(0, 0, 0, 8)
        row:SetTall(40)
        row:SetText("")

        row.Paint = function(_, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(29, 31, 43, 245))
            draw.SimpleText(ply:Nick(), "Trebuchet18", 12, h / 2, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(team.GetName(ply:Team()), "Trebuchet18", w * 0.52, h / 2, Color(170, 180, 210), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(ply:Ping(), "Trebuchet18", w - 16, h / 2, Color(210, 210, 215), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end
    end

    return false
end)

hook.Add("ScoreboardHide", "Nexus_CloseScoreboard", function()
    if IsValid(frame) then frame:Remove() end
    return false
end)
`;

type ViewMode = "lockpick" | "tab";

export default function App() {
  const [mode, setMode] = useState<ViewMode>("lockpick");
  const [zoneStart, setZoneStart] = useState(0.36);
  const [marker, setMarker] = useState(0.2);
  const [direction, setDirection] = useState(1);
  const [hits, setHits] = useState(0);
  const [timeLeft, setTimeLeft] = useState(ROUND_SECONDS);
  const [statusText, setStatusText] = useState("Попадите в зеленую зону несколько раз");
  const [showTab, setShowTab] = useState(false);
  const [copied, setCopied] = useState<"lockpick" | "tab" | null>(null);

  const goalSize = 0.2;
  const completed = hits >= REQUIRED_HITS;

  useEffect(() => {
    if (mode !== "lockpick" || completed || timeLeft <= 0) return;

    const timer = window.setInterval(() => {
      setTimeLeft((prev) => Math.max(0, prev - 1));
    }, 1000);

    return () => window.clearInterval(timer);
  }, [mode, completed, timeLeft]);

  useEffect(() => {
    if (mode !== "lockpick" || completed || timeLeft <= 0) return;

    const movement = window.setInterval(() => {
      setMarker((prev) => {
        const next = prev + direction * 0.02;
        if (next >= 1) {
          setDirection(-1);
          return 1;
        }
        if (next <= 0) {
          setDirection(1);
          return 0;
        }
        return next;
      });
    }, 16);

    return () => window.clearInterval(movement);
  }, [mode, completed, direction, timeLeft]);

  useEffect(() => {
    const down = (event: KeyboardEvent) => {
      if (event.code === "Tab") {
        event.preventDefault();
        setMode("tab");
        setShowTab(true);
      }
    };
    const up = (event: KeyboardEvent) => {
      if (event.code === "Tab") {
        event.preventDefault();
        setShowTab(false);
      }
    };

    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  const resetLockpick = () => {
    setHits(0);
    setTimeLeft(ROUND_SECONDS);
    setStatusText("Попадите в зеленую зону несколько раз");
    setMarker(0.2);
    setZoneStart(0.2 + Math.random() * 0.5);
    setMode("lockpick");
  };

  const tryHit = () => {
    if (completed || timeLeft <= 0) return;

    const success = marker >= zoneStart && marker <= zoneStart + goalSize;
    if (success) {
      setHits((prev) => prev + 1);
      setStatusText("Точное попадание");
      return;
    }

    setStatusText("Промах, попробуйте еще раз");
    setTimeLeft((prev) => Math.max(0, prev - 2));
  };

  const totalMoney = useMemo(() => {
    return players.reduce((sum, item) => {
      const value = Number(item.money.replace(/[^0-9]/g, ""));
      return sum + value;
    }, 0);
  }, []);

  const copyLua = async (key: "lockpick" | "tab", text: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(key);
    window.setTimeout(() => setCopied(null), 1200);
  };

  return (
    <div
      className="min-h-screen text-white"
      style={{
        backgroundImage:
          "linear-gradient(90deg, rgba(0,0,0,0.22) 0%, rgba(0,0,0,0.34) 100%), repeating-linear-gradient(90deg, #8f4f1e 0px, #a85b22 85px, #96511f 95px, #a75f27 170px)",
      }}
    >
      <div className="min-h-screen bg-gradient-to-b from-black/30 via-transparent to-black/55">
        <main className="mx-auto flex min-h-screen max-w-6xl flex-col items-center justify-center px-6 py-8">
          <div className="mb-6 flex items-center gap-3 text-sm text-white/85">
            <span className="font-semibold tracking-[0.18em]">NEXUS DARKRP UI</span>
            <button
              onClick={resetLockpick}
              className="rounded-md bg-white/10 px-3 py-1.5 text-xs tracking-wide transition hover:bg-white/20"
            >
              Lockpick UI
            </button>
            <button
              onClick={() => {
                setMode("tab");
                setShowTab(true);
              }}
              className="rounded-md bg-white/10 px-3 py-1.5 text-xs tracking-wide transition hover:bg-white/20"
            >
              TAB Menu Preview
            </button>
          </div>

          {mode === "lockpick" && (
            <section className="w-full max-w-[440px] rounded-xl bg-[linear-gradient(90deg,rgba(28,13,19,0.92)_0%,rgba(40,18,16,0.92)_100%)] p-6 shadow-2xl shadow-black/50 transition duration-300 animate-in fade-in slide-in-from-bottom-4">
              <h1 className="text-center text-[42px] font-bold leading-none tracking-[0.16em] text-white/90">NEXUS</h1>
              <h2 className="mt-2 text-center text-4xl font-medium">Взлом замка</h2>
              <p className="mt-2 text-center text-sm text-white/75">{statusText}</p>

              <div className="mt-4 h-3 rounded-full bg-[#2b3042]">
                <div className="flex h-full items-center justify-center text-xs font-semibold text-white/95">{hits} / {REQUIRED_HITS}</div>
              </div>

              <div className="relative mt-4 h-9 rounded-lg bg-[#2b3042]">
                <div
                  className="absolute top-0 h-full rounded-lg bg-[#3ab658] transition-all duration-300"
                  style={{ left: `${zoneStart * 100}%`, width: `${goalSize * 100}%` }}
                />
                <div
                  className="absolute -top-1 h-11 w-1 bg-white"
                  style={{ left: `${marker * 100}%`, transform: "translateX(-50%)" }}
                />
              </div>

              <button
                onClick={tryHit}
                disabled={completed || timeLeft <= 0}
                className="mt-4 w-full rounded-lg bg-[#3d67b1] py-2 text-base font-semibold transition hover:bg-[#4a76c6] disabled:cursor-not-allowed disabled:bg-[#4b4f5c]"
              >
                {completed ? "Успешно" : timeLeft <= 0 ? "Время вышло" : "Взломать"}
              </button>
              <p className="mt-2 text-center text-sm text-white/80">время раунда: 0:{String(timeLeft).padStart(2, "0")}</p>
            </section>
          )}

          {mode === "tab" && (
            <section className="w-full max-w-4xl">
              {!showTab && (
                <p className="mb-3 text-center text-sm text-white/80">
                  Удерживайте TAB, чтобы открыть меню игроков. В браузере клавиша перехватывается скриптом.
                </p>
              )}
              <div
                className={`overflow-hidden rounded-2xl border border-white/10 bg-[#121218]/95 transition duration-300 ${
                  showTab ? "translate-y-0 opacity-100" : "translate-y-4 opacity-40"
                }`}
              >
                <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
                  <div>
                    <h2 className="text-2xl font-semibold tracking-wide">NEXUS DARKRP</h2>
                    <p className="text-sm text-white/65">Онлайн: {players.length}</p>
                  </div>
                  <p className="text-sm text-white/65">Экономика сервера: ${totalMoney.toLocaleString("ru-RU")}</p>
                </div>
                <div className="px-6 py-4">
                  <div className="grid grid-cols-[2.2fr_1.5fr_1fr_0.8fr] gap-3 pb-2 text-xs uppercase tracking-[0.1em] text-white/55">
                    <span>Игрок</span>
                    <span>Работа</span>
                    <span>Баланс</span>
                    <span className="text-right">Пинг</span>
                  </div>
                  <ul className="space-y-2">
                    {players.map((player) => (
                      <li key={player.name} className="grid grid-cols-[2.2fr_1.5fr_1fr_0.8fr] gap-3 rounded-lg bg-[#1d1f2b] px-4 py-3 text-sm transition hover:bg-[#24283a]">
                        <span className="font-medium">{player.name}</span>
                        <span className="text-white/75">{player.job}</span>
                        <span className="text-white/80">{player.money}</span>
                        <span className="text-right text-white/70">{player.ping}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </section>
          )}

          <section className="mt-8 w-full max-w-6xl">
            <h3 className="text-lg font-semibold tracking-wide text-white/90">GLUA код для вставки в аддон</h3>
            <p className="mt-1 text-sm text-white/70">Структура: lua/autorun/client/cl_nexus_lockpick.lua и cl_nexus_tab.lua</p>
            <div className="mt-4 grid gap-4 lg:grid-cols-2">
              <div>
                <div className="mb-2 flex items-center justify-between text-sm text-white/75">
                  <span>Lockpick UI</span>
                  <button onClick={() => copyLua("lockpick", lockpickLua)} className="rounded bg-white/10 px-2 py-1 text-xs hover:bg-white/20">
                    {copied === "lockpick" ? "Скопировано" : "Копировать"}
                  </button>
                </div>
                <pre className="h-80 overflow-auto rounded-xl bg-black/40 p-4 text-xs leading-relaxed text-[#c7d2fe]">{lockpickLua}</pre>
              </div>
              <div>
                <div className="mb-2 flex items-center justify-between text-sm text-white/75">
                  <span>TAB Menu</span>
                  <button onClick={() => copyLua("tab", tabLua)} className="rounded bg-white/10 px-2 py-1 text-xs hover:bg-white/20">
                    {copied === "tab" ? "Скопировано" : "Копировать"}
                  </button>
                </div>
                <pre className="h-80 overflow-auto rounded-xl bg-black/40 p-4 text-xs leading-relaxed text-[#c7d2fe]">{tabLua}</pre>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
