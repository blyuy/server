include("shared.lua")

function ENT:Draw()
    self:DrawModel()

    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    if self:GetPos():Distance(lp:GetPos()) > 180 then return end

    local itemId = self:GetItemId()
    local amount = self:GetItemAmount()
    local def = NEXUS_INV_CONFIG and NEXUS_INV_CONFIG.Items and NEXUS_INV_CONFIG.Items[itemId] or nil
    local title = def and def.name or (itemId ~= "" and itemId or "Предмет")

    local ang = EyeAngles()
    local pos = self:GetPos() + Vector(0, 0, 14)
    ang = Angle(0, ang.y - 90, 90)

    cam.Start3D2D(pos, ang, 0.08)
        draw.RoundedBox(6, -110, -18, 220, 36, Color(16, 18, 26, 225))
        draw.SimpleText(title .. " x" .. tostring(amount), "DermaDefaultBold", 0, -1, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Shift + E подобрать", "DermaDefault", 0, 13, Color(165, 180, 210), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
end