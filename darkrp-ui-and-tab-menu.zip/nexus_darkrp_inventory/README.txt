NEXUS DarkRP Inventory

Папка аддона:
- addons/nexus_darkrp_inventory/

Основные возможности:
- Инвентарь в отдельной вкладке F4 (через nexus_plus)
- Подбор разрешенных энтити по Shift+E
- Подбор выброшенного оружия по Shift+E
- Локальные предметы из конфига (нельзя выбросить/потерять)
- NPC-торговцы для покупки/продажи предметов
- Дроп предметов в мир и подбор обратно

Файлы:
- lua/autorun/sh_nexus_inv_config.lua
- lua/autorun/server/sv_nexus_inventory.lua
- lua/autorun/client/cl_nexus_inventory.lua
- lua/entities/nexus_inv_vendor/*
- lua/entities/nexus_inv_worlditem/*

Команды:
- nexus_inv_open
- nexus_inv_spawn_vendor <profile_id> (superadmin)
- nexus_inv_admin (superadmin)

Настройка:
- Все предметы, локальные предметы, whitelist подбора и цены торговца
  настраиваются в sh_nexus_inv_config.lua
- Профили торговцев: NEXUS_INV_CONFIG.VendorProfiles
- В рантайме superadmin может менять локальные предметы и профили торговцев
  через UI команды nexus_inv_admin (данные сохраняются в data/nexus_inv/runtime.json)